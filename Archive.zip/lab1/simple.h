#define COSINE_ONE 45.0
#define COSINE_TWO 0
#define LOOP_NUM 10000
#define PRINT_NUM 30
